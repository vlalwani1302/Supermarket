To Run the Application - 
- Import the project as maven project
- Do a clean build
- Enter input data (groceries purchased by customer) in the file InputData.txt provided ith project.
- Data should be in format - itemname,quantity in separate lines
- Run The main class Application.java
- Item data is initialized on running main method in SupermarketUtils.java