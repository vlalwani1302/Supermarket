package test.com.tw.choices.service;

import com.tw.choices.SupermarketUtils;
import com.tw.choices.bean.Item;
import com.tw.choices.service.CheckoutService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.Optional;

public class CheckoutServiceTest{

    @Before
    public void setUp() throws Exception
    {
        Item item0 = new Item("Produce", 10.0, "Fruits", 18.0, "Apple",
                "Kg", 50.0, SupermarketUtils.STRAT_FREE, 0.0, 3,1);
        SupermarketUtils.itemMap.put("Apple", item0);

        Item item1 = new Item("Produce", 10.0, "Fruits", 18.0, "Orange",
                "Kg", 80.0,SupermarketUtils.STRAT_DISC, 20.0, 0,0);
        SupermarketUtils.itemMap.put("Orange", item1);

    }

    @Test(expected = NullPointerException.class)
    public void getCostPerItemTestException(){
        SupermarketUtils.itemMap = new HashMap<>();
        CheckoutService checkoutService = new CheckoutService();
        checkoutService.getCostPerItem("Apple", 6);
    }
    @Test
    public void getCostPerItemTestFree(){
        CheckoutService checkoutService = new CheckoutService();
        Assert.assertEquals(Optional.ofNullable(250.0), java.util.Optional.ofNullable(checkoutService.getCostPerItem("Apple", 6)));
    }

    @Test
    public void getCostPerItemTestDiscount(){
        CheckoutService checkoutService = new CheckoutService();
        Assert.assertEquals(Optional.ofNullable(128.0), java.util.Optional.ofNullable(checkoutService.getCostPerItem("Orange", 2)));
    }


}