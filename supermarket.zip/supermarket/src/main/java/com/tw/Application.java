package com.tw;


import com.tw.choices.SupermarketUtils;
import com.tw.choices.service.CheckoutService;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Application {
	public static void main(String[] args) {
		SupermarketUtils.loadData();
		Map<String, Integer> inputData = new LinkedHashMap<>();

		try {
			Scanner scanner = new Scanner(new File("src/InputData.txt"));
			while (scanner.hasNextLine()) {
				String nextLine = scanner.nextLine();
				String[] data = nextLine.split(",");
				inputData.put(data[0], Integer.valueOf(data[1]));
			}
			scanner.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		CheckoutService checkoutService = new CheckoutService();
		checkoutService.createInvoice(inputData);


	}

}
