package com.tw.choices;

import com.tw.choices.bean.Item;

import java.util.HashMap;
import java.util.Map;

public class SupermarketUtils {

    public static Map<String, Item> itemMap = new HashMap<>();
    public static final String STRAT_DISC = "Discount";
    public static final String STRAT_FREE = "Free";
//

    /**
     * @apiNote Loads initial data on startup
     */
    public static void loadData(){

        Item item0 = new Item("Produce", 10.0, "Fruits", 18.0, "Apple",
                "Kg", 50.0, STRAT_FREE, 0.0, 3,1);
        itemMap.put("Apple", item0);

        Item item1 = new Item("Produce", 10.0, "Fruits", 18.0, "Orange",
                "Kg", 80.0, STRAT_DISC, 20.0, 0,0);
        itemMap.put("Orange", item1);

        Item item2 = new Item("Produce", 10.0, "Veg", 5.0, "Potato",
                "Kg", 30.0, STRAT_FREE, 0.0, 5,2);
        itemMap.put("Potato", item2);

        Item item3 = new Item("Produce", 10.0, "Veg", 5.0, "Tomato",
                "Kg", 70.0, STRAT_DISC, 10.0, 0,0);
        itemMap.put("Tomato", item3);

        Item item4 = new Item("Dairy", 15.0, "Milk", 20.0, "Cow Milk",
                "Lt", 50.0, STRAT_FREE, 0.0, 3,1);
        itemMap.put("Cow Milk", item4);

        Item item5 = new Item("Dairy", 15.0, "Milk", 20.0, "Soy Milk",
                "Lt", 40.0, STRAT_DISC, 10.0, 0,0);
        itemMap.put("Soy Milk", item5);

        Item item6 = new Item("Dairy", 15.0, "Cheese", 20.0, "Cheddar",
                "Kg", 50.0, STRAT_FREE, 0.0, 2,1);
        itemMap.put("Cheddar", item6);

        Item item7 = new Item("Dairy", 15.0, "Cheese", 20.0, "Gouda",
                "Kg", 80.0, STRAT_DISC, 10.0, 0,0);
        itemMap.put("Gouda", item7);

    }
}
