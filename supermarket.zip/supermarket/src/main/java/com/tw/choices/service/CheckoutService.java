package com.tw.choices.service;

import com.tw.choices.SupermarketUtils;
import com.tw.choices.bean.Item;

import java.util.Map;

public class CheckoutService {
    /**
     * @apiNote prints checkout invoice for given input data
     * @param inputData
     */
    public void createInvoice(Map<String, Integer> inputData) {
        System.out.println("Item\t\tQty\t\tAmount" );
        Double totalAmountPaid = 0.0;
        Double totalMarketPrice = 0.0;

        for(Map.Entry<String, Integer> entry : inputData.entrySet()){
            Double amount = getCostPerItem(entry.getKey(), entry.getValue());
            Item item = SupermarketUtils.itemMap.get(entry.getKey());
            System.out.println(entry.getKey() + "\t\t" + inputData.get(entry.getKey()) + item.getMeasurementUnit() + "\t\t" + String.format("%.2f", amount) );

            totalAmountPaid = totalAmountPaid + amount;
            totalMarketPrice = totalMarketPrice + entry.getValue() * item.getPricePerUnit();
        }

        System.out.println("----------------------------------------------------" );
        System.out.println("Total Amount\t\t\t\t\t" + String.format("%.2f", totalAmountPaid) + " Rs");
        System.out.println("You saved\t\t" + String.format("%.2f", totalMarketPrice) + " - " + String.format("%.2f", totalAmountPaid) + " = " + String.format("%.2f", (totalMarketPrice - totalAmountPaid))/**/ + " Rs");

    }

    /**
     *@apiNote calculates amount to be paid per item after discounts
     * @param itemName
     * @param quantity
     * @return
     */
    public Double getCostPerItem(String itemName, Integer quantity) {
        Double amount = 0.0;
        Item item = SupermarketUtils.itemMap.get(itemName);

        // Calculate discount based on strategy (Free items or category discount)
        if(item.getStrategyType().equalsIgnoreCase(SupermarketUtils.STRAT_FREE)){
            // e.g. if 3Kg + 1Kg then 4Kg received but actually paid for 3Kg
            Integer itemsReceived = item.getUnitsPurchasedForFree() + item.getFreeUnits();
            Integer itemsPaidFor = item.getUnitsPurchasedForFree();

            Integer totalItemsPaidFor = (quantity / itemsReceived)* itemsPaidFor + (quantity % itemsReceived);
            amount = totalItemsPaidFor * item.getPricePerUnit();
        }else if(item.getStrategyType().equalsIgnoreCase(SupermarketUtils.STRAT_DISC)){
            Double maxDiscount = 0.0;
            if(item.getItemDiscountPercent() > maxDiscount){
                maxDiscount = item.getItemDiscountPercent();
            }
            if(item.getSubCatDiscount() > maxDiscount){
                maxDiscount = item.getSubCatDiscount();
            }
            if(item.getCategoryDiscount() > maxDiscount){
                maxDiscount = item.getCategoryDiscount();
            }

            amount = quantity * item.getPricePerUnit() * (1.0 - (maxDiscount/100));
        }


        return amount;
    }

}
