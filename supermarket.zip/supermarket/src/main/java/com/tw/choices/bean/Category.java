package com.tw.choices.bean;

public class Category {
    private String categoryName;
    private Double categoryDiscount;

    public Category(String categoryName, Double categoryDiscount) {
        this.categoryName = categoryName;
        this.categoryDiscount = categoryDiscount;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public Double getCategoryDiscount() {
        return categoryDiscount;
    }

    public void setCategoryDiscount(Double categoryDiscount) {
        this.categoryDiscount = categoryDiscount;
    }

}
