package com.tw.choices.bean;

public class SubCategory extends Category{
    private String subCatName;
    private Double subCatDiscount;

    public SubCategory(String categoryName, Double categoryDiscount, String subCatName, Double subCatDiscount) {
        super(categoryName, categoryDiscount);
        this.subCatName = subCatName;
        this.subCatDiscount = subCatDiscount;
    }

    public String getSubCatName() {
        return subCatName;
    }

    public void setSubCatName(String subCatName) {
        this.subCatName = subCatName;
    }

    public Double getSubCatDiscount() {
        return subCatDiscount;
    }

    public void setSubCatDiscount(Double subCatDiscount) {
        this.subCatDiscount = subCatDiscount;
    }

}
