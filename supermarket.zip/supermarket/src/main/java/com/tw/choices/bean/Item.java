package com.tw.choices.bean;

public class Item extends SubCategory{
    private String itemName;
    private String measurementUnit;
    private Double pricePerUnit;
    private String strategyType;
    private Double itemDiscountPercent;
    private Integer unitsPurchasedForFree;
    private Integer freeUnits;

    public Item(String categoryName, Double categoryDiscount, String subCatName, Double subCatDiscount, String itemName, String measurementUnit, Double pricePerUnit, String strategyType, Double itemDiscountPercent, Integer unitsPurchasedForFree, Integer freeUnits) {
        super(categoryName, categoryDiscount, subCatName, subCatDiscount);
        this.itemName = itemName;
        this.measurementUnit = measurementUnit;
        this.pricePerUnit = pricePerUnit;
        this.strategyType = strategyType;
        this.itemDiscountPercent = itemDiscountPercent;
        this.unitsPurchasedForFree = unitsPurchasedForFree;
        this.freeUnits = freeUnits;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getMeasurementUnit() {
        return measurementUnit;
    }

    public void setMeasurementUnit(String measurementUnit) {
        this.measurementUnit = measurementUnit;
    }

    public Double getPricePerUnit() {
        return pricePerUnit;
    }

    public void setPricePerUnit(Double pricePerUnit) {
        this.pricePerUnit = pricePerUnit;
    }

    public String getStrategyType() {
        return strategyType;
    }

    public void setStrategyType(String strategyType) {
        this.strategyType = strategyType;
    }

    public Double getItemDiscountPercent() {
        return itemDiscountPercent;
    }

    public void setItemDiscountPercent(Double itemDiscountPercent) {
        this.itemDiscountPercent = itemDiscountPercent;
    }

    public Integer getUnitsPurchasedForFree() {
        return unitsPurchasedForFree;
    }

    public void setUnitsPurchasedForFree(Integer unitsPurchasedForFree) {
        this.unitsPurchasedForFree = unitsPurchasedForFree;
    }

    public Integer getFreeUnits() {
        return freeUnits;
    }

    public void setFreeUnits(Integer freeUnits) {
        this.freeUnits = freeUnits;
    }
}
